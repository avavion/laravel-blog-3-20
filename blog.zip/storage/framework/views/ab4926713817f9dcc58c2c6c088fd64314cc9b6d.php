<!-- ***** Preloader Start ***** -->
<div id="preloader">
    <div class="jumper">
        <div></div>
        <div></div>
        <div></div>
    </div>
</div>
<!-- ***** Preloader End ***** -->
<?php /**PATH C:\OpenServer\domains\laravel-blog\resources\views/components/preloader.blade.php ENDPATH**/ ?>