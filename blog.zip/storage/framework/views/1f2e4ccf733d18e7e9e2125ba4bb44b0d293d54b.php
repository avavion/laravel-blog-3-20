<?php if($paginator->hasPages()): ?>
<?php echo e($paginator->lastPage()); ?>

    <ul class="page-numbers">
        <li><a href="#">1</a></li>
        <li class="active"><a href="#">2</a></li>
        <li><a href="#">3</a></li>
        <li><a href="<?php echo e($paginator->nextPageUrl()); ?>"><i class="fa fa-angle-double-right"></i></a></li>
    </ul>
<?php endif; ?><?php /**PATH C:\OpenServer\domains\laravel-blog\resources\views/components/pagination.blade.php ENDPATH**/ ?>